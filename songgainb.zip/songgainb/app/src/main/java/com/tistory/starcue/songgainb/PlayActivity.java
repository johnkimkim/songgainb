package com.tistory.starcue.songgainb;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Display;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;


import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerSupportFragment;

import java.util.ArrayList;

public class PlayActivity extends AppCompatActivity {

    private YouTubePlayerSupportFragment youTubePlayerFragment;
    private YouTubePlayer youTubePlayer;

    DatabaseHandler databaseHandler;
    ListAdapter listAdapter;
    ArrayList<SongModel> mList;
    private SQLiteDatabase sqLiteDatabase;
    ListView listview;

    ImageButton provbtn;
    ImageButton nextbtn;
    ImageButton sandp;
    Button back;

    String url;

    TextView textView;

//    int autoindex;
    int index;
    int newindex;
//    int indexmn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_activity);

        Dialog dialog = new Dialog(this);
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        layoutParams.dimAmount = 0.7f;

        //set dialog size
        Display display = ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        int width = (int) (display.getWidth() * 1);
        int height = (int) (display.getHeight() * 0.2);
        layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
//        getWindow().getAttributes().width = width;
//        getWindow().getAttributes().height = height;


        //set UI


        //get intent data
//        Intent intent = getIntent();
//        url = intent.getStringExtra("urlField");


        //setToolbar
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

//        listview = (ListView) findViewById(R.id.play_activity_listview);
//        //set listview
        databaseHandler.setDB(this);
        databaseHandler = new DatabaseHandler(this);
//        mList = databaseHandler.allSongList();
//        listAdapter = new ListAdapter(this, mList);
//        listview.setAdapter(listAdapter);
//        listview.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
////        listview.set(R.color.colorAccent);
//        listview.setItemsCanFocus(false);
//        listAdapter.notifyDataSetChanged();


//        sqLiteDatabase = databaseHandler.getWritableDatabase();

        provbtn = (ImageButton) findViewById(R.id.provbtn);
        nextbtn = (ImageButton) findViewById(R.id.nextbtn);
        sandp = (ImageButton) findViewById(R.id.stop_and_play);
        back = (Button) findViewById(R.id.backbtn);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        initializeYoutubePlayer();

    }

    private void initializeYoutubePlayer() {

        youTubePlayerFragment = (YouTubePlayerSupportFragment) getSupportFragmentManager()
                .findFragmentById(R.id.playView);

        if (youTubePlayerFragment == null)
            return;

        youTubePlayerFragment.initialize(Constants.YOUTUBE_KEY, new YouTubePlayer.OnInitializedListener() {

            @Override
            public void onInitializationSuccess(final YouTubePlayer.Provider provider, YouTubePlayer player,
                                                final boolean wasRestored) {

                player.setPlayerStateChangeListener(playerStateChangeListener);
                player.setPlaybackEventListener(playbackEventListener);
                player.setPlaylistEventListener(playlistEventListener);

//                sqLiteDatabase = databaseHandler.getWritableDatabase();



                if (!wasRestored) {
                    youTubePlayer = player;
                    Intent intent = getIntent();
                    index = intent.getExtras().getInt("index");
//                    int indexmn = index - 1;
//                    String urlField = intent.getExtras().getString("urlField");
//                    SongModel model = (SongModel) listAdapter.getItem(indexmn);
//                    url = model.get_url();
//                    youTubePlayer.loadVideo(url);
                    youTubePlayer.loadVideos(databaseHandler.getrandom(), index - 1, 0);
                    //set the player style default
                    youTubePlayer.setPlayerStyle(YouTubePlayer.PlayerStyle.DEFAULT);
                    //cue the 1st video by default
//                    youTubePlayer.cueVideo(youtubeVideoArrayList.get(0));

                    provbtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (youTubePlayer.hasPrevious()) {
                                youTubePlayer.previous();
                            }
                            if (!youTubePlayer.hasPrevious()) {
                                provbtn.setEnabled(false);
                                provbtn.setImageResource(R.drawable.prev_enabled_false);
                            }
                        }
                    });

                    sandp.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (youTubePlayer.isPlaying()) {
                                youTubePlayer.pause();
                                sandp.setImageResource(R.drawable.play_true);
                            } else {
                                youTubePlayer.play();
                                sandp.setImageResource(R.drawable.stop_true);
                            }
                        }
                    });


                    nextbtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
//                            String urlmore;
//                            int indexmore = indexmn;
//                            indexmore++;
//                            int indexbtn = indexmore;
//                            SongModel model = (SongModel) listAdapter.getItem(indexbtn);
//                            urlmore = model.get_url();
//                            youTubePlayer.loadVideo(urlmore);

                        if (youTubePlayer.hasNext()) {
                            youTubePlayer.next();
                        }
                        if (!youTubePlayer.hasNext()) {
                            nextbtn.setEnabled(false);
                            nextbtn.setImageResource(R.drawable.next_enabled_false);
                        }
                        }
                    });

                }

//                listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                    @Override
//                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                        SongModel model = (SongModel) adapterView.getItemAtPosition(i);
//                        newindex = model.get_index();
////                        youTubePlayer.loadVideos(databaseHandler.getrandom(), autoindex(index, newindex) - 1, 0);
////                        Intent intent = new Intent(PlayActivity.this, PlayActivity.class);
////                        intent.putExtra("index", newindex);
////                        startActivity(intent);
//                    }
//                });



//                provbtn.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        if (youTubePlayer.hasPrevious()) {
//                            youTubePlayer.previous();
//                        }
//                        if (!youTubePlayer.hasPrevious()) {
//                            provbtn.setEnabled(false);
//                            provbtn.setTextColor(getResources().getColor(R.color.setEnabled));
//                        }
//                    }
//                });
//
//                sandp.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        if (youTubePlayer.isPlaying()) {
//                            youTubePlayer.pause();
//                            sandp.setText("재생");
//                        } else {
//                            youTubePlayer.play();
//                            sandp.setText("정지");
//                        }
//                    }
//                });
//
//                nextbtn.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Intent intent = getIntent();
//                        index = intent.getExtras().getInt("index");
////                        SongModel model = (SongModel) listAdapter.getItem(indexmn +1);
////                        url = model.get_url();
//                        youTubePlayer.loadVideo(url);
////                        if (youTubePlayer.hasNext()) {
////                            youTubePlayer.next();
////                        }
////                        if (!youTubePlayer.hasNext()) {
////                            nextbtn.setEnabled(false);
////                            nextbtn.setTextColor(getResources().getColor(R.color.setEnabled));
////                        }
//                    }
//                });

            }
            @Override
            public void onInitializationFailure(YouTubePlayer.Provider arg0, YouTubeInitializationResult arg1) {

                //print or show error if initialization failed
//                Log.e(TAG, "Youtube Player View initialization failed");
            }
        });
    }

    public int autoindex(int index, int newindex) {
        Intent intent = getIntent();
        index = intent.getExtras().getInt("index");
        newindex = intent.getExtras().getInt("newindex");
        if (listview.isPressed()) {
            return newindex;
        } else {
            return index;
        }
    }

    private YouTubePlayer.PlayerStateChangeListener playerStateChangeListener = new YouTubePlayer.PlayerStateChangeListener() {
        @Override
        public void onLoading() {
            provbtn.setEnabled(false);
            provbtn.setImageResource(R.drawable.prev_enabled_false);
            sandp.setEnabled(false);
            sandp.setImageResource(R.drawable.stop_false);
            nextbtn.setEnabled(false);
            nextbtn.setImageResource(R.drawable.next_enabled_false);
        }

        @Override
        public void onLoaded(String s) {
            provbtn.setEnabled(true);
            provbtn.setImageResource(R.drawable.prev_enabled_true);
            sandp.setEnabled(true);
            sandp.setImageResource(R.drawable.stop_true);
            nextbtn.setEnabled(true);
            nextbtn.setImageResource(R.drawable.next_enabled_true);
        }

        @Override
        public void onAdStarted() {

        }

        @Override
        public void onVideoStarted() {

        }

        @Override
        public void onVideoEnded() {

        }

        @Override
        public void onError(YouTubePlayer.ErrorReason errorReason) {

        }
    };

    private YouTubePlayer.PlaybackEventListener playbackEventListener = new YouTubePlayer.PlaybackEventListener() {
        @Override
        public void onPlaying() {

        }

        @Override
        public void onPaused() {

        }

        @Override
        public void onStopped() {

        }

        @Override
        public void onBuffering(boolean b) {

        }

        @Override
        public void onSeekTo(int i) {

        }
    };

    private YouTubePlayer.PlaylistEventListener playlistEventListener = new YouTubePlayer.PlaylistEventListener() {
        @Override
        public void onPrevious() {

        }

        @Override
        public void onNext() {

        }

        @Override
        public void onPlaylistEnded() {

        }
    };


    //out layer click block
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
            return false;
        }
        return true;
    }


//    //back button in toolbar
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        int id = item.getItemId();
//
//        if (id == android.R.id.home) {
//            this.finish();
//        }
//        return super.onOptionsItemSelected(item);
//    }
}
