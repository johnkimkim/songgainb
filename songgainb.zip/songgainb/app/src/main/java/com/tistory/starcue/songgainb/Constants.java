package com.tistory.starcue.songgainb;

public class Constants {

    public static String YOUTUBE_KEY = "AIzaSyD_Gb35Yy27j4q5MALJ59f7iThin4jc5no";
}
